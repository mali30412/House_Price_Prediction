"""Prediction interface (Flask).  Run:  python app.py  ->  http://127.0.0.1:5000"""
import json
from flask import Flask, jsonify, render_template, request
from predict import predict_price

app = Flask(__name__)
META = json.load(open("models/metadata.json"))
CONDITIONS = ["Poor", "Fair", "Good", "Excellent"]


@app.get("/")
def index():
    return render_template("index.html", meta=META, conditions=CONDITIONS)


@app.post("/predict")
def predict():
    d = request.get_json(force=True)
    try:
        num = {k: float(d[k]) for k in ["area_sqft", "bedrooms", "bathrooms", "floors",
                                       "age_years", "garage_spaces", "lot_size_sqft"]}
        if num["area_sqft"] <= 0 or num["lot_size_sqft"] <= 0:
            raise ValueError("Area and lot size must be positive")
        price = predict_price(**num, neighborhood=d["neighborhood"], condition=d["condition"])
        mae = META["test_metrics"]["MAE"]
        return jsonify(price=price, low=price - mae, high=price + mae)
    except (KeyError, ValueError, TypeError) as e:
        return jsonify(error=f"Invalid input: {e}"), 400


if __name__ == "__main__":
    app.run(debug=False)
