import json, pandas as pd
from generate_data import generate
from preprocessing import clean, build_preprocessor, FEATURES


def test_clean_removes_duplicates_and_outliers():
    raw = generate(500, seed=1)
    out = clean(raw)
    assert len(out) < len(raw)
    assert not out.duplicated().any()
    assert out["area_sqft"].max() <= 10_000


def test_preprocessor_handles_missing_and_unseen():
    df = clean(generate(500, seed=2))
    prep = build_preprocessor().fit(df[FEATURES])
    X = prep.transform(df[FEATURES])
    assert not pd.isna(X).any()
    new = df[FEATURES].head(2).copy()
    new["neighborhood"] = "Unknown Place"; new["age_years"] = None
    assert prep.transform(new).shape[0] == 2


def test_model_quality_and_sanity():
    from predict import predict_price
    meta = json.load(open("models/metadata.json"))
    assert meta["test_metrics"]["R2"] > 0.85
    base = dict(bedrooms=3, bathrooms=2, floors=2, age_years=10, garage_spaces=2,
                lot_size_sqft=5000, neighborhood="Suburb North", condition="Good")
    assert predict_price(area_sqft=3000, **base) > predict_price(area_sqft=1200, **base)


def test_api():
    from app import app
    c = app.test_client()
    ok = c.post("/predict", json=dict(area_sqft=2000, lot_size_sqft=5000, bedrooms=3, bathrooms=2,
              floors=2, age_years=10, garage_spaces=2, neighborhood="Downtown", condition="Good"))
    assert ok.status_code == 200 and ok.get_json()["price"] > 0
    assert c.post("/predict", json={"area_sqft": "abc"}).status_code == 400
