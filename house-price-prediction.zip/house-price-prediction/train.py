"""Train, compare and evaluate house price models.

Usage:
    python generate_data.py                 # creates data/housing.csv (skip if you have your own)
    python train.py                         # trains on data/housing.csv
    python train.py --data my_kaggle.csv    # any CSV with the same column names
"""
import argparse, json
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline

from preprocessing import FEATURES, TARGET, build_preprocessor, clean

SEED = 42
FIG = Path("reports/figures")


def metrics(y, p):
    return {"MAE": mean_absolute_error(y, p),
            "RMSE": float(np.sqrt(mean_squared_error(y, p))),
            "R2": r2_score(y, p)}


def eda_plots(df):
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    sns.histplot(df[TARGET], bins=40, kde=True, ax=ax[0], color="#0b4f8a")
    ax[0].set_title("Price distribution")
    sns.boxplot(data=df, x="neighborhood", y=TARGET, ax=ax[1], color="#7fb2e5")
    ax[1].set_title("Price by neighborhood"); ax[1].tick_params(axis="x", rotation=30)
    plt.tight_layout(); plt.savefig(FIG / "eda_price.png", dpi=130); plt.close()

    plt.figure(figsize=(7, 5.5))
    sns.heatmap(df.select_dtypes("number").corr(), annot=True, fmt=".2f", cmap="Blues")
    plt.title("Correlation matrix"); plt.tight_layout()
    plt.savefig(FIG / "correlation.png", dpi=130); plt.close()


def main(path):
    raw = pd.read_csv(path)
    print(f"Loaded {path}: {raw.shape}")
    print("Missing values:\n", raw.isna().sum()[raw.isna().sum() > 0].to_string())
    df = clean(raw)
    print(f"After cleaning: {df.shape} (removed {len(raw) - len(df)} rows)")
    eda_plots(df)

    X, y = df[FEATURES], df[TARGET]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, random_state=SEED)

    candidates = {
        "Linear Regression": LinearRegression(),
        "Ridge": Ridge(alpha=1.0),
        "Random Forest": RandomForestRegressor(n_estimators=200, random_state=SEED, n_jobs=-1),
        "Gradient Boosting": GradientBoostingRegressor(random_state=SEED),
    }
    rows = []
    for name, est in candidates.items():
        pipe = Pipeline([("prep", build_preprocessor()), ("model", est)])
        cv = cross_val_score(pipe, X_tr, y_tr, cv=5, scoring="r2")
        pipe.fit(X_tr, y_tr)
        m = metrics(y_te, pipe.predict(X_te))
        rows.append({"Model": name, "CV R2 (mean)": cv.mean(), **m})
        print(f"{name:20s} CV R2={cv.mean():.4f}  test R2={m['R2']:.4f}  MAE={m['MAE']:,.0f}")
    results = pd.DataFrame(rows).sort_values("R2", ascending=False)

    # Hyper-parameter tuning on the best family (Gradient Boosting)
    pipe = Pipeline([("prep", build_preprocessor()),
                     ("model", GradientBoostingRegressor(random_state=SEED))])
    grid = GridSearchCV(pipe, {
        "model__n_estimators": [200, 400],
        "model__learning_rate": [0.05, 0.1],
        "model__max_depth": [2, 3, 4],
    }, cv=5, scoring="r2", n_jobs=-1)
    grid.fit(X_tr, y_tr)
    best = grid.best_estimator_
    pred = best.predict(X_te)
    final = metrics(y_te, pred)
    print("Best params:", grid.best_params_)
    print("Tuned test metrics:", {k: round(v, 4) for k, v in final.items()})
    results = pd.concat([results, pd.DataFrame([{
        "Model": "Gradient Boosting (tuned)", "CV R2 (mean)": grid.best_score_, **final}])],
        ignore_index=True)
    results.to_csv("reports/model_comparison.csv", index=False)

    # Plots
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
    ax[0].scatter(y_te, pred, s=8, alpha=.5, color="#0b4f8a")
    lim = [y_te.min(), y_te.max()]; ax[0].plot(lim, lim, "r--")
    ax[0].set(xlabel="Actual price", ylabel="Predicted price", title="Actual vs Predicted")
    resid = y_te - pred
    sns.histplot(resid, bins=40, kde=True, ax=ax[1], color="#7fb2e5")
    ax[1].set(title="Residuals", xlabel="Actual - Predicted")
    plt.tight_layout(); plt.savefig(FIG / "evaluation.png", dpi=130); plt.close()

    names = best.named_steps["prep"].get_feature_names_out()
    imp = pd.Series(best.named_steps["model"].feature_importances_, index=names).sort_values()
    plt.figure(figsize=(7, 5)); imp.tail(12).plot.barh(color="#0b4f8a")
    plt.title("Top feature importances"); plt.tight_layout()
    plt.savefig(FIG / "feature_importance.png", dpi=130); plt.close()

    # Persist model + metadata
    Path("models").mkdir(exist_ok=True)
    joblib.dump(best, "models/house_price_model.joblib")
    meta = {"best_params": grid.best_params_, "test_metrics": final,
            "n_train": len(X_tr), "n_test": len(X_te),
            "neighborhoods": sorted(df["neighborhood"].dropna().unique().tolist()),
            "defaults": {c: float(df[c].median()) for c in
                         ["area_sqft", "bedrooms", "bathrooms", "floors", "age_years",
                          "garage_spaces", "lot_size_sqft"]}}
    json.dump(meta, open("models/metadata.json", "w"), indent=2)
    print("Saved models/house_price_model.joblib")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/housing.csv")
    main(ap.parse_args().data)
