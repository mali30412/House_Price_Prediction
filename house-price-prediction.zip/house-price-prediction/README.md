# 🏠 House Price Prediction

Virtual internship project (AI & Machine Learning): an end-to-end regression pipeline that
cleans housing data, trains and compares models, evaluates them, and serves predictions
through a web interface.

![App screenshot](reports/figures/app_screenshot.png)

## Workflow
| Stage | File | What happens |
|---|---|---|
| Data | `generate_data.py` / your own CSV | Housing records with missing values, duplicates and outliers |
| Preprocessing | `preprocessing.py` | De-duplication, outlier removal, median/mode imputation, scaling, one-hot + ordinal encoding (all inside an sklearn `Pipeline` → no data leakage) |
| Model training | `train.py` | Linear, Ridge, Random Forest, Gradient Boosting; 5-fold CV; GridSearchCV tuning |
| Evaluation | `train.py` → `reports/` | MAE, RMSE, R², actual-vs-predicted, residuals, feature importance |
| Prediction interface | `app.py`, `templates/index.html` | Flask web form → JSON API → model |
| Testing | `tests/test_pipeline.py` | Cleaning, preprocessing, model sanity, API validation |

## Results (20% hold-out test set)
| Model | CV R² | Test MAE | Test RMSE | Test R² |
|---|---|---|---|---|
| Linear Regression | 0.864 | 31,039 | 47,260 | 0.845 |
| Ridge | 0.864 | 31,035 | 47,250 | 0.845 |
| Random Forest | 0.904 | 27,596 | 38,326 | 0.898 |
| Gradient Boosting | 0.930 | 23,184 | 32,085 | 0.929 |
| **Gradient Boosting (tuned)** | **0.934** | **21,936** | **29,959** | **0.938** |

## Run it
```bash
pip install -r requirements.txt
python generate_data.py        # skip if using your own data/housing.csv
python train.py                # or: python train.py --data your_file.csv
python app.py                  # open http://127.0.0.1:5000
python -m pytest -q            # run tests
```

## Using a real dataset
`train.py --data file.csv` works with any CSV containing the columns: `area_sqft, bedrooms,
bathrooms, floors, age_years, garage_spaces, lot_size_sqft, neighborhood, condition, price`.
For a different dataset (e.g. Kaggle "House Prices" / California Housing), edit the column lists at
the top of `preprocessing.py`; the rest of the pipeline is unchanged.

## Limitations
The bundled dataset is synthetic (generated with realistic price relationships), so the
metrics demonstrate the pipeline, not real-market accuracy. Predictions come with a ± MAE range.
