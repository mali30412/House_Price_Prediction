import json, pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

NAVY = colors.HexColor("#06264a")
ss = getSampleStyleSheet()
H1 = ParagraphStyle("h1", parent=ss["Heading1"], textColor=NAVY, fontSize=16, spaceBefore=10)
B = ParagraphStyle("b", parent=ss["BodyText"], fontSize=10, leading=14)
T = ParagraphStyle("t", parent=ss["Title"], textColor=NAVY, fontSize=24)
meta = json.load(open("models/metadata.json"))
res = pd.read_csv("reports/model_comparison.csv")

def img(p, w=15.5):
    from PIL import Image as PI
    iw, ih = PI.open(p).size
    return Image(p, width=w*cm, height=w*cm*ih/iw)

def table(data, widths=None):
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),NAVY),("TEXTCOLOR",(0,0),(-1,0),colors.white),
        ("FONTSIZE",(0,0),(-1,-1),9),("GRID",(0,0),(-1,-1),.4,colors.grey),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#eef3fa")])]))
    return t

s = []
s += [Spacer(1,3*cm), Paragraph("House Price Prediction", T),
      Paragraph("Virtual Internship Project - AI &amp; Machine Learning", ss["Heading3"]),
      Paragraph("Task 1 submission report", B), Spacer(1,1*cm),
      Paragraph("<b>Deliverables:</b> data preprocessing, model training, evaluation, prediction interface, "
                "documented workflow and tests.", B), PageBreak()]

s += [Paragraph("1. Objective", H1),
      Paragraph("Build a working machine-learning system that predicts a house's sale price from its "
                "characteristics, with a documented workflow, testing and a usable prediction interface.", B),
      Paragraph("2. Dataset", H1),
      Paragraph("The project uses a 3,025-row housing dataset with 9 features (area, lot size, bedrooms, bathrooms, "
                "floors, garage spaces, age, neighborhood, condition) and the target <b>price</b>. Because the "
                "development environment had no internet access, the dataset was produced by "
                "<font face='Courier'>generate_data.py</font> using realistic price relationships plus deliberate "
                "missing values (2-5% in five columns), 25 duplicate rows and 12 outliers. "
                "The pipeline accepts any real CSV with the same columns via <font face='Courier'>train.py --data</font>.", B),
      Paragraph("3. Data Preprocessing", H1),
      Paragraph("<b>Cleaning (before the split):</b> duplicates dropped; rows with invalid price removed; area outside "
                "300-10,000 sq ft removed; price outliers removed with a 3xIQR rule. 27 rows removed in total.<br/>"
                "<b>Transformation (inside a scikit-learn Pipeline, fitted on training data only to avoid leakage):</b> "
                "median imputation + standard scaling for numeric features; mode imputation + one-hot encoding for "
                "neighborhood; mode imputation + ordinal encoding (Poor &lt; Fair &lt; Good &lt; Excellent) for condition. "
                "Unseen categories are handled safely at prediction time.", B),
      img("reports/figures/eda_price.png"), img("reports/figures/correlation.png", 10), PageBreak()]

rows = [["Model","CV R2","MAE","RMSE","Test R2"]] + [
    [r.Model, f"{r['CV R2 (mean)']:.3f}", f"{r.MAE:,.0f}", f"{r.RMSE:,.0f}", f"{r.R2:.3f}"] for _, r in res.iterrows()]
bp = meta["best_params"]
s += [Paragraph("4. Model Training", H1),
      Paragraph("Data was split 80/20 (random_state=42): %d training and %d test rows. Four models were compared with "
                "5-fold cross-validation: Linear Regression, Ridge, Random Forest and Gradient Boosting. "
                "Gradient Boosting performed best and was tuned with GridSearchCV over n_estimators, learning_rate and "
                "max_depth. Best parameters: n_estimators=%d, learning_rate=%s, max_depth=%d." %
                (meta["n_train"], meta["n_test"], bp["model__n_estimators"], bp["model__learning_rate"], bp["model__max_depth"]), B),
      Paragraph("5. Evaluation", H1), table(rows, [6*cm,2.2*cm,2.6*cm,2.6*cm,2.2*cm]), Spacer(1,.4*cm),
      Paragraph("The tuned model reaches R2 = %.3f with a mean absolute error of about $%s on unseen data. Residuals are "
                "centred around zero and actual-vs-predicted points follow the diagonal. Area, neighborhood and condition "
                "are the most influential features." % (meta["test_metrics"]["R2"], f"{meta['test_metrics']['MAE']:,.0f}"), B),
      img("reports/figures/evaluation.png"), img("reports/figures/feature_importance.png", 11), PageBreak()]

s += [Paragraph("6. Prediction Interface", H1),
      Paragraph("A Flask web application (<font face='Courier'>app.py</font>) exposes a form for all 9 inputs and a "
                "<font face='Courier'>/predict</font> JSON endpoint. It validates input (returns HTTP 400 on bad data) and "
                "shows the estimated price with a +/- MAE range.", B),
      img("reports/figures/app_screenshot.png", 12),
      Paragraph("7. Testing", H1),
      Paragraph("Four automated tests (all passing): cleaning removes duplicates/outliers; preprocessing handles missing "
                "and unseen values; model R2 &gt; 0.85 and larger houses cost more; the API accepts valid and rejects invalid input.", B),
      Paragraph("8. Workflow &amp; Reproducibility", H1),
      Paragraph("generate_data.py -&gt; preprocessing.py -&gt; train.py (CV, tuning, evaluation, saves model) -&gt; "
                "app.py (interface) -&gt; tests. Commands are listed in README.md.", B),
      Paragraph("9. Limitations &amp; Future Work", H1),
      Paragraph("The bundled data is synthetic, so metrics demonstrate the pipeline rather than real-market accuracy. "
                "Next steps: train on a real dataset (e.g. Kaggle House Prices), add geographic features, try XGBoost/LightGBM, "
                "add SHAP explanations and deploy the app online.", B)]

SimpleDocTemplate("reports/House_Price_Prediction_Report.pdf", pagesize=A4, leftMargin=2*cm, rightMargin=2*cm,
                  topMargin=2*cm, bottomMargin=2*cm, title="House Price Prediction").build(s)
print("ok")
