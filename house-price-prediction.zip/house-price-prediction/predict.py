"""Shared prediction helper (used by the web app, CLI and tests)."""
import joblib, pandas as pd
from preprocessing import FEATURES

_model = None

def get_model(path="models/house_price_model.joblib"):
    global _model
    if _model is None:
        _model = joblib.load(path)
    return _model

def predict_price(**features) -> float:
    row = pd.DataFrame([{f: features.get(f) for f in FEATURES}])
    return float(get_model().predict(row)[0])

if __name__ == "__main__":
    print(f"${predict_price(area_sqft=2000, bedrooms=3, bathrooms=2, floors=2, age_years=10, garage_spaces=2, lot_size_sqft=5000, neighborhood='Suburb North', condition='Good'):,.0f}")
