"""Generate a realistic synthetic housing dataset (used when no real CSV is available).

Includes deliberate missing values, duplicates and outliers so the
preprocessing stage has real work to do.
"""
import numpy as np
import pandas as pd

NEIGHBORHOODS = {  # name: price multiplier
    "Downtown": 1.45, "Lakeside": 1.30, "Suburb North": 1.10,
    "Suburb South": 1.00, "Old Town": 0.90, "Industrial Edge": 0.70,
}
CONDITIONS = {"Poor": 0.85, "Fair": 0.95, "Good": 1.05, "Excellent": 1.18}


def generate(n=3000, seed=42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    area = np.clip(rng.normal(1800, 650, n), 450, 6000).round()
    bedrooms = np.clip((area / 600 + rng.normal(0, 0.8, n)).round(), 1, 7).astype(int)
    bathrooms = np.clip((bedrooms * 0.6 + rng.normal(0, 0.6, n)).round(), 1, 6).astype(int)
    floors = rng.choice([1, 2, 3], n, p=[0.45, 0.45, 0.10])
    age = rng.integers(0, 80, n)
    garage = rng.choice([0, 1, 2, 3], n, p=[0.15, 0.35, 0.40, 0.10])
    lot = np.clip(area * rng.uniform(1.2, 4.0, n), 600, 30000).round()
    neigh = rng.choice(list(NEIGHBORHOODS), n, p=[0.12, 0.10, 0.22, 0.24, 0.20, 0.12])
    cond = rng.choice(list(CONDITIONS), n, p=[0.08, 0.25, 0.47, 0.20])

    base = (
        45_000 + 105 * area + 9_000 * bedrooms + 14_000 * bathrooms
        + 6_000 * floors - 900 * age + 11_000 * garage + 1.8 * lot
    )
    price = base * np.vectorize(NEIGHBORHOODS.get)(neigh) * np.vectorize(CONDITIONS.get)(cond)
    price *= rng.lognormal(0, 0.07, n)  # market noise

    df = pd.DataFrame(dict(
        area_sqft=area, bedrooms=bedrooms, bathrooms=bathrooms, floors=floors,
        age_years=age, garage_spaces=garage, lot_size_sqft=lot,
        neighborhood=neigh, condition=cond, price=price.round(-2),
    ))

    # --- messy-data realism ---
    for col, frac in [("age_years", .04), ("lot_size_sqft", .05), ("bathrooms", .02),
                      ("neighborhood", .02), ("condition", .03)]:
        df.loc[rng.choice(n, int(n * frac), replace=False), col] = np.nan
    out = rng.choice(n, 12, replace=False)
    df.loc[out, "area_sqft"] *= 4          # data-entry outliers
    df = pd.concat([df, df.sample(25, random_state=seed)], ignore_index=True)  # duplicates
    return df


if __name__ == "__main__":
    df = generate()
    df.to_csv("data/housing.csv", index=False)
    print(f"Saved data/housing.csv  shape={df.shape}")
