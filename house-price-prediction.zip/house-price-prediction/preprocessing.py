"""Data preprocessing: cleaning + sklearn ColumnTransformer."""
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, OrdinalEncoder, StandardScaler

TARGET = "price"
NUMERIC = ["area_sqft", "bedrooms", "bathrooms", "floors", "age_years",
           "garage_spaces", "lot_size_sqft"]
NOMINAL = ["neighborhood"]
ORDINAL = ["condition"]
CONDITION_ORDER = ["Poor", "Fair", "Good", "Excellent"]
FEATURES = NUMERIC + NOMINAL + ORDINAL


def clean(df: pd.DataFrame) -> pd.DataFrame:
    """Row-level cleaning done BEFORE the train/test split (no leakage: nothing is learned from data)."""
    df = df.drop_duplicates().copy()
    df = df.dropna(subset=[TARGET])
    df = df[df[TARGET] > 0]
    # remove extreme outliers in area using a fixed physical-plausibility rule + IQR on price
    df = df[df["area_sqft"].between(300, 10_000)]
    q1, q3 = df[TARGET].quantile([0.25, 0.75])
    iqr = q3 - q1
    df = df[df[TARGET].between(q1 - 3 * iqr, q3 + 3 * iqr)]
    return df.reset_index(drop=True)


def build_preprocessor() -> ColumnTransformer:
    """Imputation + scaling + encoding. Fitted only on training data inside the Pipeline."""
    numeric = Pipeline([("impute", SimpleImputer(strategy="median")),
                        ("scale", StandardScaler())])
    nominal = Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                        ("onehot", OneHotEncoder(handle_unknown="ignore"))])
    ordinal = Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                        ("ord", OrdinalEncoder(categories=[CONDITION_ORDER],
                                               handle_unknown="use_encoded_value",
                                               unknown_value=-1))])
    return ColumnTransformer([("num", numeric, NUMERIC),
                              ("nom", nominal, NOMINAL),
                              ("ord", ordinal, ORDINAL)])
